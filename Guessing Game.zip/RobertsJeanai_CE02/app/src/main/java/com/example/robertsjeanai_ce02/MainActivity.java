package com.example.robertsjeanai_ce02;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;

    // Jeanai Roberts
    // GPL - C202201
    // MainActivity.java

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Main Activity: ";

    private int guessesRemaining = 4;
    private final ArrayList<FieldObject> objectArrayList = new ArrayList<>();
    private final ArrayList<Integer> randIntList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.submitBttn).setOnClickListener(v -> {

            int i = 1;

            for(Integer r : randIntList){

                String view = "textNumberSigned" + i;
                int viewId = getResources().getIdentifier(view, "id", this.getPackageName());

                TextView tvField = findViewById(viewId);
                String tvString = tvField.getText().toString();

                if (!tvString.isEmpty() || !tvString.trim().isEmpty()){

                    int mGuess = checkTextViews(tvField.getText().toString());
                    FieldObject fObject = new FieldObject(mGuess, tvField, r);
                    objectArrayList.add(fObject);
                }
                else{

                    Toast emptyToast = Toast.makeText(this, R.string.toast_BlankField, Toast.LENGTH_SHORT);
                    emptyToast.show();

                }

                i++;
            }

            if (objectArrayList.size() == 4){
                validateValues();
            }

        });

        setRandValues();

    }

    private Integer checkTextViews(String userInput) {

        int value = -1;
        Toast stringAlert;

        try{
            value = Integer.parseInt(userInput);
            return value;
        } catch (NumberFormatException e) {
            stringAlert = Toast.makeText(this, R.string.toast_CannotParse, Toast.LENGTH_SHORT);
            stringAlert.show();
            return value;
        }

    }

    private void validateValues(){

        int correctValue = getResources().getColor(R.color.green, null);
        int lowValue = getResources().getColor(R.color.blue, null);
        int highValue = getResources().getColor(R.color.red, null);
        Toast wrongValueAlert;

        boolean wrongValueFound = false;


        // Check Fields

        for(FieldObject f : objectArrayList){

            TextView tV = findViewById(f.getTV().getId());

            if (f.getGuess().equals(f.getAnswer())){
                tV.setTextColor(correctValue);
                wrongValueFound = false;
            }
            else{
                if (f.getGuess() > f.getAnswer()){
                    tV.setTextColor(highValue);

                }
                else{
                    tV.setTextColor(lowValue);
                }

                wrongValueFound = true;

            }

        }


        // Check if wrongValueFound is True
       if (wrongValueFound){
           guessesRemaining = guessesRemaining - 1;

           if (guessesRemaining > 0){

               String mGuessRemain = guessesRemaining + " " + getResources().getString(R.string.toast_GuessesRemaining);
               wrongValueAlert = Toast.makeText(this, mGuessRemain, Toast.LENGTH_SHORT);
               wrongValueAlert.show();

           }
           else{

               AlertDialog.Builder loseAlert = new AlertDialog.Builder(MainActivity.this);
               loseAlert.setTitle(R.string.alert_Loser);

               loseAlert.setPositiveButton(R.string.bttn_Reset, (dialog, which) -> resetGame());
               loseAlert.show();

           }

       }
       else{

           AlertDialog.Builder winAlert = new AlertDialog.Builder(MainActivity.this);
           winAlert.setTitle(R.string.alert_Winner);


           winAlert.setPositiveButton(R.string.bttn_Reset, (dialog, which) -> resetGame());
           winAlert.show();

       }
    }


    private Integer randNumberGenerator(){
        int min = 0;
        int max = 9;

        return (int) (Math.random()*(max-min+1)+min);
    }

    private void setRandValues(){

        int i;

        for(i = 0; i < 4; i++){
            randIntList.add(randNumberGenerator());
        }

        Log.i(TAG, "setRandValues: " + randIntList.toString());
    }

    private void resetGame(){

        for(FieldObject f : objectArrayList){
            TextView tV = findViewById(f.getTV().getId());
            tV.setText(null);
            tV.setTextColor(getResources().getColor(R.color.black, null));
        }

        guessesRemaining = 4;
        objectArrayList.clear();
        randIntList.clear();
        setRandValues();
    }
}