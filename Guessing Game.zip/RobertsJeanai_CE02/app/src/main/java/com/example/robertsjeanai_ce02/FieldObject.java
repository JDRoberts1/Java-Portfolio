package com.example.robertsjeanai_ce02;

import android.widget.TextView;

import org.w3c.dom.Text;

public class FieldObject {

    private Integer guessAttempt;
    private TextView tvField;
    private Integer answerInt;

    FieldObject(Integer _Guess, TextView _Field, Integer _Answer){
        guessAttempt = _Guess;
        tvField = _Field;
        answerInt = _Answer;
    }

    public Integer getGuess(){return guessAttempt;}

    public TextView getTV(){return tvField;}

    public Integer getAnswer(){return answerInt;}
}
