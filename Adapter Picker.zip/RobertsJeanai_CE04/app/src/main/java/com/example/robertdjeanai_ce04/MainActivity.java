package com.example.robertdjeanai_ce04;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    // Jeanai Roberts
    // GPL - 220101
    // MainActivity.Java

    Spinner viewSelector;
    Spinner adapterSelector;
    ListView listView;
    GridView gridView;

    ArrayList<Person> mPeople = new ArrayList<>();

    private final String TAG = "Main Activity ";
    private Integer viewIndex;
    private Integer adapterIndex;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.data_ListView);
        gridView = findViewById(R.id.data_GridView);

        listView.setOnItemClickListener(mClickView);
        gridView.setOnItemClickListener(mClickView);

        populateSpinner();
        populateData();

        viewIndex = viewSelector.getSelectedItemPosition();
        adapterIndex = viewSelector.getSelectedItemPosition();
    }


    private void populateSpinner(){
        viewSelector = findViewById(R.id.spinner_ViewType);
        adapterSelector = findViewById(R.id.spinner_AdapterType);

        ArrayAdapter<CharSequence> viewAdapter = ArrayAdapter.createFromResource(this, R.array.view_array, R.layout.support_simple_spinner_dropdown_item);
        viewAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.adapter_array, R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        viewSelector.setAdapter(viewAdapter);
        viewSelector.setOnItemSelectedListener(mViewSelected);

        adapterSelector.setAdapter(adapter);
        adapterSelector.setOnItemSelectedListener(mAdapterSelected);
    }

    private void simpleAdapterSetUp(){

        final String keyName = "fullName";
        final String keyBirthday = "age";

        ArrayList<HashMap<String, String>> personData = new ArrayList<>();

        for(Person p: mPeople){

            HashMap<String, String> map = new HashMap<>();

            map.put(keyName, p.getFullName());
            map.put(keyBirthday, p.getBirthDate());

            personData.add(map);
        }

        String[] keys = new String[]{keyName, keyBirthday};
        int[] viewIDs = new  int[]{
                R.id.fullNameTextView, R.id.birthdayTextView
        };

        SimpleAdapter sa = new SimpleAdapter(this, personData, R.layout.layout_gridview, keys, viewIDs);
        if (viewIndex == 0){

            listView.setAdapter(sa);
        }
        else{

            gridView.setAdapter(sa);

        }

    }

    private void setUpListViewAdapter(){

        if (adapterIndex == 0){
            // Set up Array Adapter
            ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);

            for (int i = 0; i < mPeople.size(); i++) {

                aa.add(mPeople.get(i).getFullName());

            }

            listView.setAdapter(aa);
        }
        else if (adapterIndex == 1){
            // Set up Simple Adapter
            simpleAdapterSetUp();
        }
        else{
            // Set up Base Adapter
            BaseAdapterClass ba = new BaseAdapterClass(this, mPeople);
            listView.setAdapter(ba);
        }
    }

    private void setUpGridViewAdapter(){

        if (adapterIndex == 0){
            // Set up Array Adapter
            ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);

            for (int i = 0; i < mPeople.size(); i++) {

                aa.add(mPeople.get(i).getFullName());

            }

            gridView.setAdapter(aa);

        }
        else if (adapterIndex == 1){
            // Set up Simple Adapter
            simpleAdapterSetUp();
        }
        else{
            // Set up Base Adapter
            BaseAdapterClass ba = new BaseAdapterClass(this, mPeople);
            gridView.setAdapter(ba);
        }
    }


    void switchViewDisplay(){

        if (viewIndex == 0){

            setUpListViewAdapter();
        }
        else if (viewIndex == 1){

            setUpGridViewAdapter();
        }

    }

    private final OnItemSelectedListener mViewSelected = new OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            viewIndex = position;

            if (position == 0){
                switchViewDisplay();
                listView.setVisibility(View.VISIBLE);
                gridView.setVisibility(View.GONE);

            } else if (position == 1) {
                switchViewDisplay();
                listView.setVisibility(View.GONE);
                gridView.setVisibility(View.VISIBLE);

            }

            Log.i(TAG, "onViewSelected: " + position);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };

    private final OnItemSelectedListener mAdapterSelected = new OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            String adapterView;
            adapterIndex = position;

            if (position == 0){
                adapterView = "Array Adapter";

                if (viewIndex == 0){

                    setUpListViewAdapter();
                }
                else if (viewIndex == 1){
                    setUpGridViewAdapter();
                }

                Log.i(TAG,  "onAdapterSelected: " + position + adapterView);

            } else if (position == 1) {
                adapterView = "Sample Adapter";

                if (viewIndex == 0){

                    setUpListViewAdapter();
                }
                else if (viewIndex == 1){
                    setUpGridViewAdapter();
                }

                Log.i(TAG,  "onAdapterSelected: " + position + adapterView);

            } else if (position == 2){
                adapterView = "Base Adapter";

                if (viewIndex == 0){

                    setUpListViewAdapter();
                }
                else if (viewIndex == 1){
                    setUpGridViewAdapter();
                }

                Log.i(TAG,  "onAdapterSelected: " + position + adapterView);

            }


        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {


        }
    };

    void populateData(){

        Resources res = getResources();

        mPeople.add(new Person("Kristy","Erickson","08/22/1996", res.getIdentifier("kristyerickson", "drawable", getPackageName())));
        mPeople.add(new Person("Ernie","Villegas","09/29/1988", res.getIdentifier("ernievillegas", "drawable", getPackageName())));
        mPeople.add(new Person("Aimee","Lister","10/11/1990", res.getIdentifier("aimeelister", "drawable", getPackageName())));
        mPeople.add(new Person("Maddox","Stacey","01/18/1995", res.getIdentifier("maddoxstacey", "drawable", getPackageName())));
        mPeople.add(new Person("Abdullahi","Forbes","12/02/1996", res.getIdentifier("abdullahiforbes", "drawable", getPackageName())));
        mPeople.add(new Person("Lorena","Brock","01/21/1995", res.getIdentifier("lorenabrock", "drawable", getPackageName())));
        mPeople.add(new Person("Imaan","Martinez","05/08/1998", res.getIdentifier("imaanmartinez", "drawable", getPackageName())));
        mPeople.add(new Person("Lainey","Daniels","06/08/1990", res.getIdentifier("laineydaniels", "drawable", getPackageName())));
        mPeople.add(new Person("Liyana","Busby","11/08/1960", res.getIdentifier("liyanabusby", "drawable", getPackageName())));
        mPeople.add(new Person("Lewis","Yu","11/25/1988", res.getIdentifier("lewisyu", "drawable", getPackageName())));

    }


    private final AdapterView.OnItemClickListener mClickView = new AdapterView.OnItemClickListener() {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

            Person selectedPerson = mPeople.get(position);

            builder.setTitle(selectedPerson.getFullName());
            builder.setMessage(selectedPerson.getBirthDate());
            builder.setIcon(selectedPerson.getImage());
            builder.setPositiveButton(R.string.bttn_pos, null);

            builder.show();
        }

    };

}