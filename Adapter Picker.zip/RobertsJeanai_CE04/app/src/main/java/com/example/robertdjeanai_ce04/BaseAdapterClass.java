package com.example.robertdjeanai_ce04;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class BaseAdapterClass extends BaseAdapter {

    // Jeanai Roberts
    // GPL - 220101
    // BaseAdapterClass.Java

    // Base ID
    private static final long Base_ID = 0x1011;
    private Context mContext = null;
    private ArrayList<Person> mPeople = null;

    // Constructor
    public BaseAdapterClass(Context _context, ArrayList<Person> _people){
        mContext = _context;
        mPeople = _people;
    }

    @Override
    public int getCount() {
        if (mPeople != null){
            return  mPeople.size();
        }

        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (mPeople != null && position >= 0 && position < mPeople.size()){
            return  mPeople.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return Base_ID + position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder vh;
        Person person = (Person)getItem(position);

        if (convertView == null){

            convertView = LayoutInflater.from(mContext).inflate(R.layout.layout_listview, parent, false);

            vh = new ViewHolder(convertView);
            convertView.setTag(vh);
        } else{
            vh = (ViewHolder) convertView.getTag();
        }

        // Set text & images for UI components
        if (person != null){
            vh.tv_FullName.setText(person.getFullName());

            try {
                Date mBirthDate = new SimpleDateFormat("MM/dd/yyyy").parse(person.getBirthDate());
                vh.tv_Birthday.setText(new SimpleDateFormat("MM/dd/yyyy").format(mBirthDate));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            vh.iv_ProfilePicture.setImageResource(person.getImage());

        }

        return convertView;
    }

    static class ViewHolder{
        TextView tv_FullName;
        TextView tv_Birthday;
        ImageView iv_ProfilePicture;

        public ViewHolder(View _layout){
            tv_FullName = _layout.findViewById(R.id.fullNameTV);

            tv_Birthday = _layout.findViewById(R.id.birthdayTV);

            iv_ProfilePicture = _layout.findViewById(R.id.profileImageView);
        }

    }


}
