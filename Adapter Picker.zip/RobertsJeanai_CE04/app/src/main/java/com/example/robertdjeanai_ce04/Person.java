package com.example.robertdjeanai_ce04;

public class Person {

    // Jeanai Roberts
    // GPL - 220101
    // Person.Java

    // Information about the person
    private final String mFirstName;
    private final String mLastName;
    private final String mBirthday;
    private final Integer mPicture;

    Person(String _firstName, String _lastName, String _birthday, Integer _image){
        mFirstName = _firstName;
        mLastName = _lastName;
        mBirthday = _birthday;
        mPicture = _image;
    }


    String getFullName(){
        return getFirstName() + " " + getLastName();
    }

    String getFirstName() {
        return mFirstName;
    }

    String getLastName() {
        return mLastName;
    }

    String getBirthDate(){ return mBirthday; }

    Integer getImage(){ return mPicture; }

}
