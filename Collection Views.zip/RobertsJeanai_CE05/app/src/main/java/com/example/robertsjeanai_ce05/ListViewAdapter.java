package com.example.robertsjeanai_ce05;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {

    private static final int BASE_ID = 0*01000000;
    Context mContext;
    ArrayList<Course> mCourseList;

    // Adapter Constructor
    public ListViewAdapter(Context _context, ArrayList<Course> _courses){
        mContext = _context;
        mCourseList = _courses;
    }

    @Override
    public int getCount() {
        if(mCourseList != null){
            return mCourseList.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (mCourseList != null && position >= 0 && position < mCourseList.size()){
            return  mCourseList.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return BASE_ID + position;
    }

    // Child Layout
    public View getView(int position, View convertView, ViewGroup parent){
        ViewHolder vh;
        Course currentCourse = mCourseList.get(position);

        if (convertView == null){

            convertView = LayoutInflater.from(mContext).inflate(R.layout.portrait_mode, parent, false);
            vh = new ViewHolder(convertView);
            convertView.setTag(vh);
        } else{
            vh = (ViewHolder) convertView.getTag();
        }


        vh.tv_CourseName.setText(currentCourse.getCourseName());
        vh.tv_courseTerm.setText(currentCourse.getCourseTerm());




        return convertView;
    }

    static class ViewHolder{
        TextView tv_CourseName;
        TextView tv_courseTerm;

        public ViewHolder(View _layout){
            tv_CourseName = _layout.findViewById(R.id.tv_CourseName);

            tv_courseTerm = _layout.findViewById(R.id.tv_Term);

        }

    }

}
