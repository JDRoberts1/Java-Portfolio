package com.example.robertsjeanai_ce05;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

// Jeanai Roberts
// GPL - 220101
// MainActivity.Java

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Main Activity: ";
    ArrayList<Course> mCourseList = new ArrayList<>();
    ListView lv;
    Spinner cSpinner;
    Integer cIndex;
    Integer orientation;
    ScrollView dV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        populateData();
        handleOrientation();
        dV = findViewById(R.id.detailsView);
        dV.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        handleOrientation();
    }

    // TODO: Populate data for listview and spinner
    void populateData(){
        Resources res = getResources();

        mCourseList.add(new Course("Project and Portfolio III", "MDV338", 86.71D,"Liz Canacari Rose", res.getIdentifier("lizcanacarirose", "drawable", getPackageName()), "The Project and Portfolio III: Mobile Development course combines hands-on learning experiences with summative and formative portfolio assessments. This course enables students to synthesize their development and design skills for the Apple mobile platform to plan, develop, and deploy an interactive mobile application for use on Apple devices."));
        mCourseList.add(new Course("iOS Development II", "MDV3731",72.06D, "Patti Dacosta", res.getIdentifier("pattidacosta", "drawable", getPackageName()), "Students continue to explore the benefits of using Apple frameworks that enable deep-system integration to build immersive mobile applications that take full advantage of the Apple mobile platform. Students are challenged to research and implement advanced features and functionality to take advantage of device integration and modern complementary frameworks."));
        mCourseList.add(new Course("Mobile User Experience", "MDV3111",82.9D, "Christopher Chapman", res.getIdentifier("christopherchapman", "drawable", getPackageName()), "This course explores platform guidelines and the means to apply standards to achieve highly usable interfaces that consider user preferences as well as functional requirements."));
        mCourseList.add(new Course("Statistics", "STA3026",75.92D, "Ryan Hill", res.getIdentifier("ryanhill", "drawable", getPackageName()),"The Statistics course provides students with an in-depth exploration of statistical concepts. Students learn data collection methods, organization of data, descriptive analysis, and visual representation of data."));
        mCourseList.add(new Course("Project and Portfolio III", "MDV239",81.45, "Robin Groff Alarcon", res.getIdentifier("robingroffalarcon", "drawable", getPackageName()), "This course synthesizes usability, programming, and design techniques to enable students to design and build an interactive application. These applications will allow users to traverse and display dynamic content deployed to a targeted device."));
        mCourseList.add(new Course("Visual Frameworks", "MDV1830",86.30D, "Travis Setz", res.getIdentifier("travissetz", "drawable", getPackageName()), "This course explores how to identify specific use cases for mobile applications and how to create an appropriate application flow that supports programming logic, usability, and overall user experience. Students will design user interfaces (UI) that employ proper visual components and maintain consistency across UIs, thus building a more cohesive and intuitive experience for the user."));
        mCourseList.add(new Course("Interfaces and Usability", "DEV2318",77.04D, "Oscar Cortez", res.getIdentifier("oscarcortez", "drawable", getPackageName()), "The Interfaces and Usability course focuses on designing intuitive, usable interfaces for varying screen sizes and devices. Students learn fundamental interaction-design and usability principles coupled with proven user interface–design patterns. "));
        mCourseList.add(new Course("Project and Portfolio II", "MDV229",82.04D, "Doug Oberndorf", res.getIdentifier("dougoberndorf", "drawable", getPackageName()), "This course identifies usability and design concerns present in the project scope to facilitate the delivery of dynamic content for an interactive application. This course explores the requirements for presenting content to users on a targeted device."));
        mCourseList.add(new Course("Advanced Scalable Data Infrastructures", "MDV2430",85.57D, "Chris Maxwell", res.getIdentifier("chrismaxwell", "drawable", getPackageName()), "Students learn intermediate programming concepts with an introduction to objects and modular design. Students gain a deeper knowledge base for developing interactive dynamic content."));
        mCourseList.add(new Course("Database Structures", "DEV231",85.40D, "Rebecca Carroll", res.getIdentifier("rebeccacarroll", "drawable", getPackageName()), "Students learn how to access and process stored data and become familiar with the benefits that creating database structures can provide in regard to such concepts as data optimization and table normalization. Students also explore the differences between relational and non-relational databases."));

    }

    // TODO: Set up Listview for portrait mode
    void setUpListView(){

        lv = findViewById(R.id._ListView);


        lv.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                dV.setVisibility(View.VISIBLE);
                cIndex = position;
                populateDetailsView();
            }
        });

        ListViewAdapter la = new ListViewAdapter(this,mCourseList);
        lv.setAdapter(la);

    }

    // TODO: Populate spinner when in Landscape view
    void populateSpinner(){

        cSpinner = findViewById(R.id.courseSelector);

        ArrayList<String> courseNames = new ArrayList<>();

        for(Course c : mCourseList){
            courseNames.add(c.getCourseName());
        }

        ArrayAdapter<String> spinAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, courseNames);
        spinAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        cSpinner.setAdapter(spinAdapter);

        cSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cIndex = position;
                populateDetailsView();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.i(TAG, "onNothingSelected: ");
            }
        });
    }

    // TODO: Handle orientation
    void handleOrientation(){
        orientation = getResources().getConfiguration().orientation;
        
        if (orientation == 1){
            setContentView(R.layout.activity_main);
            setUpListView();
        }
        else {
            setContentView(R.layout.landscape_mode);
            populateSpinner();
        }

        if (cIndex == null){
            cIndex = 0;
        }

        populateDetailsView();

    }

    // TODO: Method used to populate Details View in either Landscape or Portrait mode
    void populateDetailsView(){


        Course sCourse = mCourseList.get(cIndex);

        TextView courseName = findViewById(R.id.tv_ActivityCourseName);
        TextView courseTerm = findViewById(R.id.tv_ActivityCourseTerm);
        TextView instructorName = findViewById(R.id.tv_ActivityInstructor);
        TextView courseGrade = findViewById(R.id.tv_ActivityGrade);
        ImageView instructorImg = findViewById(R.id.professorImg);
        TextView courseDesc = findViewById(R.id.tv_ActivityCourseDesc);

        courseName.setText(sCourse.getCourseName());
        instructorName.setText(sCourse.getCourseProfessor());
        courseTerm.setText(sCourse.getCourseTerm());
        courseGrade.setText(sCourse.toString());
        instructorImg.setImageResource(sCourse.getProfessorImage());
        courseDesc.setText(sCourse.getCourseDesc());

    }


}