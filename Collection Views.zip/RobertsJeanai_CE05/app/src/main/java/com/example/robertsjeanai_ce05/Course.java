package com.example.robertsjeanai_ce05;

// Jeanai Roberts
// GPL - 220101
// MainActivity.Java

import androidx.annotation.NonNull;

public class Course {

   private final String courseName;
   private final String course;
   private final Double courseGrade;
   private final String courseProfessor;
   private final Integer professorImage;
   private final String courseDesc;

    public Course(String _courseName, String _course, Double _courseGrade, String _courseProfessor, Integer _professorImage, String _courseDec) {
        courseName = _courseName;
        course = _course;
        courseGrade = _courseGrade;
        courseProfessor = _courseProfessor;
        professorImage = _professorImage;
        courseDesc = _courseDec;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseTerm(){return course;}

    public Double getCourseGrade() {
        return courseGrade;
    }

    // TODO: toString Method to convert Double to String
    @NonNull
    public String toString(){ return Double.toString(getCourseGrade()); }

    public String getCourseProfessor() {
        return courseProfessor;
    }

    public Integer getProfessorImage() {
        return professorImage;
    }

    public String getCourseDesc(){return courseDesc;}
}
