package com.example.robertsjeanai_ce03;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Jeanai Roberts
    // GPL - C202201
    // MainActivity.Java

    private TextView mUserInput = null;
    private TextView avg_Output;
    private TextView median_Output;
    private NumberPicker index_Selector;
    private final String TAG = "Data Passed: ";
    DecimalFormat decimalFormat = new DecimalFormat("###.##");
    private Double mStringAvg = 0.00d;
    private final List<String> mEntriesList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUserInput = findViewById(R.id.text_UserInput);
        avg_Output = findViewById(R.id.text_AvgNum);
        median_Output = findViewById(R.id.text_MediNum);
        index_Selector = findViewById(R.id.selector_Index);

        findViewById(R.id.bttn_Add).setOnClickListener(mBtnClickAdd);
        findViewById(R.id.bttn_View).setOnClickListener(mBtnClickView);

    }

    private final View.OnClickListener mBtnClickAdd = v -> {

        String newWordString = mUserInput.getText().toString().toLowerCase();

        String whiteSpaceCheck = newWordString.trim();

        // Check for Empty, Whitespace, Duplicate values
        // Alert the user of invalid string using a toast
        Toast inputAlert;

        if (newWordString.isEmpty()){
            inputAlert = Toast.makeText(this, R.string.toast_EmptyString, Toast.LENGTH_SHORT);
            inputAlert.show();
        } else if (whiteSpaceCheck.isEmpty()){
            inputAlert = Toast.makeText(this, R.string.toast_SpaceString, Toast.LENGTH_SHORT);
            inputAlert.show();
        } else if (mEntriesList.contains(newWordString)){
            inputAlert = Toast.makeText(this, R.string.toast_NonUniqueValue, Toast.LENGTH_SHORT);
            inputAlert.show();
        }
        else{

            mEntriesList.add(newWordString);

            calculateAvg();
            calculateMedian();

            mUserInput.setText("");

            Log.i(TAG,newWordString + " " + mStringAvg);

            updateNumberPicker();

        }

    };

    private final View.OnClickListener mBtnClickView = v -> {

        if (!mEntriesList.isEmpty()){
            Integer rIndex = index_Selector.getValue();
            String rString = mEntriesList.get(rIndex);

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

            builder.setTitle("Selected Word");
            builder.setMessage(rString);

            // Remove Button
            builder.setPositiveButton(R.string.bttn_dialog_pos, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    Log.i(TAG, "Request Index: " + rIndex + "Removed word : " + rString);

                    mEntriesList.remove(rString);

                    calculateAvg();
                    calculateMedian();
                    updateNumberPicker();
                }
            });

            // Ok Button
            builder.setNegativeButton(R.string.bttn_dialof_neg, null);
            builder.show();
        }

    };

    private void calculateMedian(){

        double mStringMedian;

        if (mEntriesList.isEmpty()){
            mStringMedian = 0D;
        }
        else {

            List<Integer> mEntriesLengthList = new ArrayList<>();

            for (String e: mEntriesList) {

                mEntriesLengthList.add(e.length());
            }

            Collections.sort(mEntriesLengthList);

            int listLength = mEntriesLengthList.size();

            int index1 = listLength / 2;


            if (listLength % 2  == 0){

                // Sum of middle two elements and divide this sum by 2

                int index2 = listLength / 2 - 1;

                mStringMedian = (double) (mEntriesLengthList.get(index1) + mEntriesLengthList.get(index2)) / 2;


            }
            else{

                mStringMedian = mEntriesList.get(index1).length();
            }
        }

        median_Output.setText(decimalFormat.format(mStringMedian));
    }

    private void calculateAvg(){

        // AVG = Sum/Count
        int sum = 0;

        if (!mEntriesList.isEmpty()){

            for (String e: mEntriesList) {
                sum += e.length();
            }

            mStringAvg = (double) sum / mEntriesList.size();
        }
        else {
            mStringAvg = 0D;
        }


        avg_Output.setText(decimalFormat.format(mStringAvg));
    }

    private void updateNumberPicker(){

        if (mEntriesList.size() > 1) {

            index_Selector.setMinValue(0);
            index_Selector.setMaxValue(mEntriesList.size() - 1);
        }
        else if (mEntriesList.size() == 1){

            index_Selector.setMinValue(0);
            index_Selector.setMaxValue(0);
        }

    }

}