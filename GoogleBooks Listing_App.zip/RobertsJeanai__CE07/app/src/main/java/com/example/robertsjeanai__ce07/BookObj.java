package com.example.robertsjeanai__ce07;



public class BookObj {

    // Jeanai Roberts
    // GPL - 202201
    // BookObj.Java

    private final String mTitle;
    private final String mSubtitle;
    private final String mImgSmall;

    BookObj(String mTitle, String mSubtitle, String mImgSmall) {
        this.mTitle = mTitle;
        this.mSubtitle = mSubtitle;
        this.mImgSmall = mImgSmall;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmSubtitle() {
        return mSubtitle;
    }

    public String getmImgSmall() {
        return mImgSmall;
    }
}
