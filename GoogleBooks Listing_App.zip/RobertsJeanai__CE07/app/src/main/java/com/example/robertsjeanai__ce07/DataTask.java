package com.example.robertsjeanai__ce07;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.commons.io.IOUtil;

public class DataTask extends AsyncTask<String, Void, String>  {

    // Jeanai Roberts
    // GPL - 202201
    // DataTask.Java

    private static final String TAG = "AsyncTask: ";
    final private OnFinished mInterface;

    interface OnFinished{
        void onPre();
        void onPost(String result);
        void onCan();
        void onFin();
    }


    DataTask(OnFinished _Interface){ mInterface = _Interface; }

    // TODO: onPreExecute
    @Override
    protected void onPreExecute(){
        // TODO: DISPLAY PROGRESSBAR
        // TODO: Check For Connection
        mInterface.onPre();
    }

    // TODO: doInBackground
    @Override
    protected String doInBackground(String... strings) {

        // TODO: PULL DATA FROM API
        // utilize a stream reading library
        // URL String
        String urlAddress = strings[0];

        // URL Object
        URL url = null;

        // Open Connection
        HttpURLConnection con = null;

        try {
            url = new URL(urlAddress);
            con = (HttpURLConnection) url.openConnection();
            con.connect();

        } catch (Exception e){
            e.printStackTrace();
        }

        InputStream is = null;
        String result = "ERROR: Result not set...";
        try{
            is = con.getInputStream();
            result = IOUtil.toString(is, "UTF-8");
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally{
            if (con != null){
                try{
                    is.close();
                } catch (Exception e){
                    e.printStackTrace();
                }

                con.disconnect();
            }
        }

        // Display Results
        Log.i(TAG, "results: " + result);


        return result;
    }

    @Override
    public void onPostExecute(String result) {
        mInterface.onPost(result);
        mInterface.onFin();
    }

}
