package com.example.robertsjeanai__ce07;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.image.SmartImageView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements DataTask.OnFinished{

    // Jeanai Roberts
    // GPL - 202201
    // MainActivity.Java

    private static final String TAG = "Main Activity: ";
    DataTask dt = null;
    ArrayList<BookObj> bookList = new ArrayList<>();

    SmartImageView bookImg;
    TextView titleTV;
    TextView subTV;
    ProgressBar pGBar;
    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bookImg = (SmartImageView) findViewById(R.id.bookCoverIV);
        pGBar = (ProgressBar) findViewById(R.id.dataProgressBar);
        titleTV = (TextView) findViewById(R.id.titleTV);
        subTV = (TextView) findViewById(R.id.subtitleTV);
        gridView = (GridView) findViewById(R.id._BookGridView);

        // URL String
        String urlAddress = "https://www.googleapis.com/books/v1/volumes?q=android";

        if (isConnected()){
            dt = new DataTask(MainActivity.this);
            dt.execute(urlAddress);
        }
        else{
            Toast.makeText(this, "No Network Connection", Toast.LENGTH_SHORT).show();

        }

    }

    protected boolean isConnected(){
        ConnectivityManager mgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        if(mgr != null){
            NetworkInfo info = mgr.getActiveNetworkInfo();
            if(info != null){
                return info.isConnected();
            }
        }
        return false;
    }

    @Override
    public void onPre() {
        // TODO: Start Progress BAR
        pGBar.setIndeterminate(true);
        pGBar.animate();

    }


    @Override
    public void onPost(String result) {
        // TODO: Hide Progress Bar
        pGBar.setVisibility(View.GONE);
        parseJson(result);
    }

    @Override
    public void onCan() {

    }

    @Override
    public void onFin() {
        // TODO: Display Results
        GridViewAdapter gVA = new GridViewAdapter(this, bookList);
        gridView.setAdapter(gVA);
    }

    void parseJson(String _jsonDataString){

        // Title & Subtitle
        String _title;
        String _subtitle;
        // Small Thumbnail
        String imgUrl;

        try {
            JSONObject outerOBJ = new JSONObject(_jsonDataString);
            JSONArray outerArr = outerOBJ.getJSONArray("items");

            for (int i = 0; i < outerArr.length(); i++){
                JSONObject obj = outerArr.getJSONObject(i);
                JSONObject innerOuterObj = obj.getJSONObject("volumeInfo");
                _title = innerOuterObj.getString("title");

                boolean subExists = innerOuterObj.has("subtitle");

                if (subExists){
                    _subtitle = innerOuterObj.getString("subtitle");

                }
                else{
                    _subtitle = null;
                }

                JSONObject innerObj = innerOuterObj.getJSONObject("imageLinks");
                imgUrl = innerObj.getString("smallThumbnail");

                bookList.add(new BookObj(_title, _subtitle, imgUrl));

            }

        } catch(Exception e){
            e.printStackTrace();
        }

        // Check final ArrayList
        Log.i(TAG, "parseJson: " + bookList.size());

    }

}