package com.example.robertsjeanai__ce07;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.loopj.android.image.SmartImageView;

import java.util.ArrayList;


public class GridViewAdapter extends BaseAdapter {

    // Jeanai Roberts
    // GPL - 202201
    // GridViewAdapter.Java

    private static final long Base_ID = 0x1011;
    private Context mContext = null;
    private ArrayList<BookObj> mBooks = null;

    public GridViewAdapter(Context _context, ArrayList<BookObj> _books){
        mContext = _context;
        mBooks = _books;
    }

    @Override
    public int getCount() {
        if (mBooks != null){
            return mBooks.size();
        }

        return 0;
    }

    @Override
    public Object getItem(int position) {

        if (mBooks != null && position >= 0 && position < mBooks.size()){
            return mBooks.get(position);
        }

        return null;
    }

    @Override
    public long getItemId(int position) {
        return Base_ID + position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder vh;
        BookObj book = (BookObj) getItem(position);

        if (convertView == null){
            convertView = LayoutInflater.from(mContext).inflate(R.layout.gridview_layout, parent, false);
            vh = new ViewHolder(convertView);
            convertView.setTag(vh);
        }
        else {
            vh = (ViewHolder) convertView.getTag();
        }

        if (book != null){
            vh.tv_Title.setText(book.getmTitle());

            if (book.getmSubtitle() != null){
                vh.tv_SubTile.setText(book.getmSubtitle());
            }
            else {
                vh.tv_SubTile.setText(R.string.nullSubTitle);
            }

            vh.iv_BookImg.setImageUrl(book.getmImgSmall());
        }

        return convertView;
    }

    static class ViewHolder{
        TextView tv_Title;
        TextView tv_SubTile;
        SmartImageView iv_BookImg;

        public ViewHolder(View _layout){

            tv_Title = _layout.findViewById(R.id.titleTV);
            tv_SubTile = _layout.findViewById(R.id.subtitleTV);
            iv_BookImg = _layout.findViewById(R.id.bookCoverIV);

        }
    }
}
