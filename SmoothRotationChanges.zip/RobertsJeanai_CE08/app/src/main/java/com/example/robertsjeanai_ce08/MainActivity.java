package com.example.robertsjeanai_ce08;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

// Jeanai Roberts
// GPL - C202201
// MainActivity.java

public class MainActivity extends AppCompatActivity {

    Button submitBttn;
    ListView valueList;
    TextView inputTV;
    ArrayList<String> inputList = new ArrayList<>();
    ArrayAdapter<String> lvAdapter;

    private static final String TAG = "Main Activity: ";
    final String lk = "listKey";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submitBttn = (Button) findViewById(R.id.bttn_Submit);
        valueList = (ListView) findViewById(R.id.lv_InputList);


        inputTV = (TextView) findViewById(R.id.tv_Input);

        lvAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, inputList);

        submitBttn.setOnClickListener(bttnClick);
        valueList.setAdapter(lvAdapter);


    }


    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putStringArrayList(lk, inputList);
        super.onSaveInstanceState(savedInstanceState);

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);

        ArrayList<String> list = savedInstanceState.getStringArrayList(lk);

        for ( String i : list){
            inputList.add(i);
        }

        lvAdapter.notifyDataSetChanged();
    }


    View.OnClickListener bttnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.i(TAG, "onClick: ");

            if (validateString()){
                lvAdapter.notifyDataSetChanged();
            }

            inputTV.setText(R.string.tv_Reset);

        }
    };


    private Boolean validateString(){

        String input = (String) inputTV.getText().toString();

        if (input.trim().length() == 0){
            Toast.makeText(this,R.string.toast_Blankfield, Toast.LENGTH_SHORT).show();

        }
        else if (input.length() != 0){
            inputList.add(input);
            return true;
        }
        else{
            Toast.makeText(this,R.string.toast_Blankfield, Toast.LENGTH_SHORT).show();
            Log.i(TAG, "validateString: Invalid String");
        }

        return false;

    }

}