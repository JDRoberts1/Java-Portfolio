package com.example.robertsjeanai_ce01;

import android.widget.Button;

public class Card {

    // Jeanai Roberts
    // GPL - C202201
    // Card.java

    private final Integer cardTag;
    private final Character cardBack;
    private final Button cardBttn;

    public Card(Integer _cardTag, Character _cardBack, Button _cardBttn){

        cardTag = _cardTag;
        cardBack = _cardBack;
        cardBttn = _cardBttn;
    }


    public Integer getCardTag(){return cardTag;}

    public Character getCardBack(){
        return cardBack;
    }

    public Button getCardButton(){
        return cardBttn;
    }

}
