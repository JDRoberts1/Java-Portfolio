package com.example.robertsjeanai_ce01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    // Jeanai Roberts
    // GPL - C202201
    // MainActivity.java

    private static final String TAG = "Main Activity: ";
    public ArrayList<Character> characterArrayList = new ArrayList<>();
    public ArrayList<Card> mSelectedCards = new ArrayList<>();
    public ArrayList<Card> mCards = new ArrayList<>();
    Integer mGuessAttempted = 0;
    Integer mMatchCount = 0;
    Button selectedBttn;
    Button mResetBttn;
    TextView mGuessCounter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGuessCounter = findViewById(R.id.tv_CounterGuesses);
        generateCards();
        setUpTable();

        mResetBttn = findViewById(R.id.bttn_Reset);
        mResetBttn.setOnClickListener(mBttnResetClick);
        mResetBttn.setVisibility(View.INVISIBLE);

        Log.i(TAG, "onCreate: " + mCards.size());

    }


    private void generateCards() {

        for (char c = 'A'; c <= 'H'; c++) {

            Log.i(TAG, "generateCards: " + c + "Size: " + characterArrayList.size());
            characterArrayList.add(c);
        }


        characterArrayList.addAll(characterArrayList);
        Collections.shuffle(characterArrayList);
        Log.i(TAG, "generateCards: " + characterArrayList.size());


    }

    private final View.OnClickListener mBttnClick = new Button.OnClickListener() {

        @Override
        public void onClick(View v) {

            int bttnTag = Integer.parseInt(v.getTag().toString());
            Card selectedCard = mCards.get(bttnTag);

            if (mSelectedCards.size() == 2) {

                validateCards();

                mSelectedCards.clear();

                selectedBttn = selectedCard.getCardButton();
                selectedBttn.setText(selectedCard.getCardBack().toString());
                mSelectedCards.add(selectedCard);

            } else if (mSelectedCards.size() <= 2) {

                selectedBttn = selectedCard.getCardButton();
                selectedBttn.setText(selectedCard.getCardBack().toString());
                mSelectedCards.add(selectedCard);
            }

        }

    };

    private final View.OnClickListener mBttnResetClick = new Button.OnClickListener() {

        @Override
        public void onClick(View v) {

            resetTable();
        }

    };


    private void setUpTable() {

        int i = 0;
        for (Character c : characterArrayList) {

            String bttnName = "cell_" + i;
            int bttnID = getResources().getIdentifier(bttnName, "id", this.getPackageName());
            Button bttn = findViewById(bttnID);
            bttn.setOnClickListener(mBttnClick);

            Log.i(TAG, "setUpTable: " + i);
            Card mCard = new Card(i, c, bttn);
            mCards.add(mCard);
            i++;

        }
    }

    private void resetTable() {

        mResetBttn.setVisibility(View.INVISIBLE);
        mSelectedCards.clear();
        characterArrayList.clear();
        mCards.clear();

        mGuessAttempted = 0;
        mMatchCount = 0;

        generateCards();

        int i = 0;

        for (Character c : characterArrayList) {

            String bttnName = "cell_" + i;
            int bttnID = getResources().getIdentifier(bttnName, "id", this.getPackageName());
            Button bttn = findViewById(bttnID);
            bttn.setVisibility(View.VISIBLE);
            bttn.setText(R.string.cardFront);

            Log.i(TAG, "setUpTable: " + i);
            Card mCard = new Card(i, c, bttn);
            mCards.add(mCard);
            i++;

        }

    }


    private void validateCards() {

        Card c1 = mSelectedCards.get(0);
        Card c2 = mSelectedCards.get(1);

        if (c1.getCardBack() == c2.getCardBack()) {

            c1.getCardButton().setVisibility(View.INVISIBLE);
            c2.getCardButton().setVisibility(View.INVISIBLE);
            mMatchCount++;
            Log.i(TAG, "validateCards: Match");
            Log.i(TAG, "validateCards: " + mMatchCount);
        } else {

            c1.getCardButton().setText(R.string.cardFront);
            c2.getCardButton().setText(R.string.cardFront);
            Log.i(TAG, "validateCards: NonMatch");
        }

        if (mMatchCount == 8) {
            mResetBttn.setVisibility(View.VISIBLE);
        }

        mGuessAttempted++;
        mGuessCounter.setText(mGuessAttempted.toString());

    }


}