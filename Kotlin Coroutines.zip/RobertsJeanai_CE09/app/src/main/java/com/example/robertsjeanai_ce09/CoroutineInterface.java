package com.example.robertsjeanai_ce09;

public interface CoroutineInterface {

    // Jeanai Roberts
    // GPL - 202201
    // CoroutineInterface.java

    void onPre();
    void onPost(String Data);
    void onFin();
}
