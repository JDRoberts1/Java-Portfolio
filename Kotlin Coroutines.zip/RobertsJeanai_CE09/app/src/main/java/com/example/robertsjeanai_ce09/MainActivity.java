package com.example.robertsjeanai_ce09;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements CoroutineInterface {


    // Jeanai Roberts
    // GPL - 202201
    // MainActivity.java

    ProgressBar preDisplay;
    GridView dataView;
    ArrayList<Book> bookList = new ArrayList<>();
    CoroutineTask coroutine = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preDisplay = (ProgressBar) findViewById(R.id.preProgressBar);
        dataView = (GridView) findViewById(R.id.data_GridView);
        dataView.setVisibility(View.GONE);

        String webAddress = "https://www.googleapis.com/books/v1/volumes?q=programming";

        if(isConnected()){
            coroutine = new CoroutineTask(this);
            coroutine.coBegin(webAddress);
        }
        else {
            Toast.makeText(this, "No Network Connection", Toast.LENGTH_LONG).show();
        }


    }

    protected boolean isConnected(){
        ConnectivityManager mgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        if(mgr != null){
            NetworkInfo info = mgr.getActiveNetworkInfo();
            if(info != null){
                return info.isConnected();
            }
        }
        return false;
    }

    void parseJson(String _jsonDataString){

        // Title & Subtitle
        String _title;
        String _subtitle;
        // Small Thumbnail
        String imgUrl;

        try {
            JSONObject outerOBJ = new JSONObject(_jsonDataString);
            JSONArray outerArr = outerOBJ.getJSONArray("items");

            for (int i = 0; i < outerArr.length(); i++){
                JSONObject obj = outerArr.getJSONObject(i);
                JSONObject innerOuterObj = obj.getJSONObject("volumeInfo");
                _title = innerOuterObj.getString("title");

                boolean subExists = innerOuterObj.has("subtitle");

                if (subExists){
                    _subtitle = innerOuterObj.getString("subtitle");

                }
                else{
                    _subtitle = null;
                }

                JSONObject innerObj = innerOuterObj.getJSONObject("imageLinks");
                imgUrl = innerObj.getString("smallThumbnail");

                bookList.add(new Book(_title, _subtitle, imgUrl));

            }

        } catch(Exception e){
            e.printStackTrace();
        }


    }

    @Override
    public void onPre(){
        preDisplay.setIndeterminate(true);
        preDisplay.animate();
    }

    @Override
    public void onPost(String data) {
        parseJson(data);
        preDisplay.setVisibility(View.GONE);
        dataView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onFin() {
        GridViewAdapter adapter = new GridViewAdapter(this,bookList);
        dataView.setAdapter(adapter);
    }
}