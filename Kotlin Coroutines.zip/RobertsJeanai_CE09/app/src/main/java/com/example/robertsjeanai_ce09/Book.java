package com.example.robertsjeanai_ce09;

public class Book {

    // Jeanai Roberts
    // GPL - 202201
    // Book.java

    private final String mTitle;
    private final String mSubtitle;
    private final String mImgSmall;

    Book(String mTitle, String mSubtitle, String mImgSmall) {
        this.mTitle = mTitle;
        this.mSubtitle = mSubtitle;
        this.mImgSmall = mImgSmall;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmSubtitle() {
        return mSubtitle;
    }

    public String getmImgSmall() {
        return mImgSmall;
    }
}
