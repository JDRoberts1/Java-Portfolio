package com.example.robertsjeanai_ce09

import java.io.InputStream
import java.net.HttpURLConnection
import kotlinx.coroutines.*
import org.apache.commons.io.IOUtil
import java.net.URL


class CoroutineTask(private val mInterface: CoroutineInterface) {

    // Jeanai Roberts
    // GPL - 202201
    // CoroutineTask.kt

    fun coBegin(_webAddress: String){
        onPreExecute()
        CoroutineScope(Dispatchers.Main).launch {
            onPostExecute(_webAddress)
        }
    }

    private fun onPreExecute(){
        mInterface.onPre()
    }

    private suspend fun doInBackground(_webAddress: String) = withContext(Dispatchers.IO){

        var resultData = ""


        val url = URL(_webAddress)
        var con = url.openConnection() as HttpURLConnection
        con.connect()



        val iS = con.inputStream as InputStream
        resultData = IOUtil.toString(iS, "UTF-8")

        iS.close()
        con.disconnect()



        return@withContext resultData

    }

    private suspend fun onPostExecute(webAddress: String){
        val data = doInBackground(webAddress)
        mInterface.onPost(data)
        mInterface.onFin()
    }


}